echo "building prodcons.c file"
gcc -m32 -o prodcons -I /u/OSLab/jwm54/linux-2.6.23.1/include/ ./src/prodcons.c;